// Run: node tests/logic.test.js
const assert = require('assert');
const L = require('../app.js');

// --- input validation ---
assert.strictEqual(L.parseMultiplier('2.40x'), 2.4);
assert.strictEqual(L.parseMultiplier('1.25X'), 1.25);
assert.strictEqual(L.parseMultiplier(' 5,60 '), 5.6);
assert.strictEqual(L.parseMultiplier('৩.৫০x'), 3.5);   // Bengali digits
assert.strictEqual(L.parseMultiplier('1'), 1);
for (const bad of ['', 'abc', '0.99', '-2', '2.345', '1e3', '100001', '2..3', 'x']) {
  assert.strictEqual(L.parseMultiplier(bad), null, 'should reject ' + bad);
}

// --- statistics ---
const s = L.computeStats([1.2, 1.5, 2, 3, 10]);
assert.strictEqual(s.n, 5);
assert.ok(Math.abs(s.mean - 3.54) < 1e-9);
assert.strictEqual(s.median, 2);
assert.strictEqual(s.below, 2);            // 1.2, 1.5
assert.strictEqual(s.above, 3);            // 2 counts as "at or above 2x"
assert.ok(Math.abs(s.pctBelow - 40) < 1e-9);
assert.strictEqual(L.computeStats([]).n, 0);
assert.strictEqual(L.computeStats([1, 4]).median, 2.5);

const b = L.bucketCounts([1.0, 1.49, 1.5, 1.99, 2, 2.99, 3, 5, 9.99, 10, 55]);
assert.deepStrictEqual(b.map(x => x.count), [2, 2, 2, 1, 2, 2]);
assert.ok(Math.abs(b.reduce((a, x) => a + x.pct, 0) - 100) < 1e-9);

// --- wilson ---
const w = L.wilson(50, 100);
assert.ok(Math.abs(w.lo - 0.404) < 0.002 && Math.abs(w.hi - 0.596) < 0.002);

// --- streaks & signal (hand-checked) ---
assert.deepStrictEqual(L.currentStreak([2.5, 1.1, 1.2]), { type: 'below', len: 2 });
assert.deepStrictEqual(L.currentStreak([1.1, 2.5, 3]), { type: 'above', len: 2 });
const seq = [1.2, 1.3, 1.1, 2.5, 1.1, 1.2, 1.3, 3, 1.5, 1.4, 1.2, 1.1];
const e = L.evaluateSignal(seq, 3);
assert.strictEqual(e.tested, 3);
assert.strictEqual(e.correct, 2);
assert.strictEqual(e.incorrect, 1);
assert.ok(Math.abs(e.accuracy - 2 / 3) < 1e-9);
assert.strictEqual(e.activeNow, true);
assert.strictEqual(e.streakNow, 4);
assert.strictEqual(L.evaluateSignal([3, 3, 3], 3).tested, 0);
assert.strictEqual(L.evaluateSignal([3, 3, 3], 3).accuracy, null);

// --- indicators: nothing shown without data ---
const i0 = L.indicators([1.5, 2]);
assert.strictEqual(i0.avgLast10, undefined);
assert.strictEqual(i0.pctAboveLast20, undefined);

// --- demo generator ---
let seed = 12345;
const rng = () => (seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296;
const demo = L.genDemo(20000, rng);
assert.ok(demo.every(v => v >= 1 && v <= 1000));
const share2 = demo.filter(v => v >= 2).length / demo.length;
assert.ok(share2 > 0.45 && share2 < 0.52, 'demo >=2x share ' + share2);   // theory ~0.485

// --- honesty check: signal on random demo data should NOT beat baseline by much ---
const big = L.genDemo(20000, rng);
const eb = L.evaluateSignal(big, 3);
assert.ok(Math.abs(eb.accuracy - eb.baseline) < 0.05,
  'independent rounds: signal ' + eb.accuracy.toFixed(3) + ' vs baseline ' + eb.baseline.toFixed(3));

// --- CSV ---
const csv = L.toCsv([{ id: 1, v: 2.4, ts: 0 }], 'real');
assert.ok(csv.startsWith('id,multiplier,timestamp_iso,local_time,dataset'));
assert.ok(csv.includes('2.40') && csv.includes('1970-01-01T00:00:00.000Z'));

// --- translations: same keys in both languages ---
const bn = Object.keys(L.I18N.bn).sort().join(), en = Object.keys(L.I18N.en).sort().join();
assert.strictEqual(bn, en);

console.log('All logic tests passed. demo>=2x share=' + share2.toFixed(3) +
  ', signal=' + eb.accuracy.toFixed(3) + ' vs baseline=' + eb.baseline.toFixed(3));
